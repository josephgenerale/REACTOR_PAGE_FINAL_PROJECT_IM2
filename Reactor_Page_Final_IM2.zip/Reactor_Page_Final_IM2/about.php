<?php
$pageTitle = "About";
$additionalCSS = '<link href="res/about.css?v=' . time() . '" rel="stylesheet" type="text/css"/>';
include 'views/header.php';
?>

<br>
<br>
<br>
<div class="content">
    <h1>About Reactor Page</h1>
    <p>
        Reactor Page is a social media platform designed for seamless interaction and meaningful content sharing. 
        It empowers users to express themselves through posts, manage their profiles, and connect with others 
        in a secure and user-friendly environment.
    </p>
</div>

<div class="copyright">
    <p>Copyright 2025 @ Reactor Page, All Rights Reserved.</p>
</div>

<?php include 'views/footer.php'; ?>
