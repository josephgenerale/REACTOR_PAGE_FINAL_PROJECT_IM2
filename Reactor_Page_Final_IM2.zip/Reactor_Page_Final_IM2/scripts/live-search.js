document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');

    searchInput.addEventListener('keyup', function () {
        let query = searchInput.value.trim();

        if (query.length < 3) {
            searchResults.innerHTML = '';
            searchResults.style.display = 'none';
            return;
        }

        fetchSearchResults(query);
    });

    // 🟣 Add event delegation so dynamically inserted links can be clicked
    searchResults.addEventListener('click', function (e) {
        const target = e.target.closest('a');
        if (target) {
            window.location.href = target.href;
        }
    });

    function fetchSearchResults(query) {
        fetch(`models/live-search.php?query=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                searchResults.innerHTML = '';
                if (data.length === 0) {
                    searchResults.style.display = 'none';
                    return;
                }

                data.forEach(item => {
                    const div = document.createElement('div');
                    div.classList.add('search-result-item');

                    if (item.type === 'user') {
                        const img = item.profile_pic ? item.profile_pic : './media/default-profile.png';
                        div.innerHTML = `
                            <a href="profile.php?uid=${item.uid}">
                                <img src="${img}" class="result-img">
                                ${item.firstname} ${item.lastname} (@${item.username})
                            </a>
                        `;
                    } else if (item.type === 'post') {
                        div.innerHTML = `
                            <a href="view-post.php?pid=${item.pid}">
                                <strong>${item.firstname} ${item.lastname}</strong>: ${item.text_content}
                            </a>
                        `;
                    }

                    searchResults.appendChild(div);
                });

                searchResults.style.display = 'block';
            })
            .catch(error => {
                console.error('Error fetching search results:', error);
                searchResults.innerHTML = 'There was an error while searching.';
                searchResults.style.display = 'block';
            });
    }
});
