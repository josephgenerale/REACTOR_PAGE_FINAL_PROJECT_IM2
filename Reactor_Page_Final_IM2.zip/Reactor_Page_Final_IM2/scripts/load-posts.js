$(document).ready(function() {
    loadPosts();

    function loadPosts() {
        $.ajax({
            url: './models/get-posts.php', 
            type: 'GET',
            data: { type: 'all' },
            success: function(response) {
                if ($('#post-container').length) {
                    $('#post-container').html(response);
                } else {
                    console.error('Post container not found.');
                }
            },
            error: function(xhr) {
                console.error('Error loading posts:', xhr.responseText);
            }
        });
    }
});
