<?php include 'views/header.php'; ?>

<link rel="stylesheet" href="res/eula.css?v=<?php echo time(); ?>">

<div class="eula-container">
    <h2>End User License Agreement (EULA)</h2>
    <p>
        Welcome to our platform! Before using our services, please read our End User License Agreement carefully.
    </p>
    <p>
        By using this platform, you agree to the following terms:
        <ul>
            <li>You must be at least 16+ years old to use this platform.</li>
            <li>You agree not to engage in any illegal activity on this platform.</li>
            <li>We may suspend or terminate your account for any violation of these terms.</li>
            <!-- Add more terms as needed -->
        </ul>
    </p>
    <p>By continuing with the sign-up, you agree to our terms and conditions.</p>
    <a href="sign-up.php">Go back to Sign Up</a>
</div>

<?php include 'views/footer.php'; ?>
