<?php
session_start();
require_once('models/dbconnection.php');

if (!isset($_SESSION['uid'])) {
    echo "<h2>Please log in to search.</h2>";
    exit;
}

$conn = create_connection();

$searchTerm = isset($_GET['query']) ? trim($_GET['query']) : '';

if (empty($searchTerm)) {
    echo "<h2>No search query entered.</h2>";
    exit;
}

$searchTermLike = "%" . $conn->real_escape_string($searchTerm) . "%";

// Search for users
$userQuery = $conn->prepare("SELECT uid, firstname, lastname, username, profile_pic FROM user WHERE firstname LIKE ? OR lastname LIKE ? OR username LIKE ?");
$userQuery->bind_param("sss", $searchTermLike, $searchTermLike, $searchTermLike);
$userQuery->execute();
$userResult = $userQuery->get_result();

// Search for posts
$postQuery = $conn->prepare("SELECT p.pid, p.text_content, u.firstname, u.lastname FROM post p JOIN user u ON p.uid = u.uid WHERE p.text_content LIKE ?");
$postQuery->bind_param("s", $searchTermLike);
$postQuery->execute();
$postResult = $postQuery->get_result();

$pageTitle = "Search Results";
$additionalCSS = '<link rel="stylesheet" href="res/search.css">';
include('views/header.php');
?>

<div class="search-results-container">
    <h2>Search Results for "<?php echo htmlspecialchars($searchTerm); ?>"</h2>

    <div class="results-section">
        <h3>Users</h3>
        <?php if ($userResult->num_rows > 0): ?>
            <?php while ($row = $userResult->fetch_assoc()): ?>
                <?php $pic = $row['profile_pic'] ? $row['profile_pic'] : './media/default-profile.png'; ?>
                <div class="result-entry user-result">
                    <img src="<?php echo htmlspecialchars($pic); ?>" alt="Profile Picture">
                    <a href="profile.php?uid=<?php echo $row['uid']; ?>">
                        <?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?>
                    </a> (@<?php echo htmlspecialchars($row['username']); ?>)
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="result-empty">No users found matching your search.</div>
        <?php endif; ?>
    </div>

    <div class="results-section">
        <h3>Posts</h3>
        <?php if ($postResult->num_rows > 0): ?>
            <?php while ($row = $postResult->fetch_assoc()): ?>
                <div class="result-entry post-result">
                    <strong><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?></strong>:
                    <a href="view-post.php?pid=<?php echo $row['pid']; ?>">
                        <span><?php echo htmlspecialchars($row['text_content']); ?></span>
                    </a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="result-empty">No posts found matching your search.</div>
        <?php endif; ?>
    </div>
</div>

<?php include('views/footer.php'); ?>
