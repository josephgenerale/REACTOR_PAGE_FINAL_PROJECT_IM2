<?php 
// Start the session to manage user login
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['uid'])) {
    header("Location: sign-in.php");
    exit;
}

// Include necessary files
include 'views/header.php';
require 'models/profile_controller.php';

// Database connection
$conn = create_connection();

// Determine which user's profile to view (either the current user or another user)
$viewUserId = isset($_GET['uid']) ? $_GET['uid'] : $_SESSION['uid'];

// Fetch user details from the database
$query = "SELECT * FROM user WHERE uid = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $viewUserId);
$stmt->execute();
$userResult = $stmt->get_result();

// Check if the user exists
if ($userResult->num_rows > 0) {
    $userData = $userResult->fetch_assoc();
} else {
    echo "<p>User not found.</p>";
    exit();
}

?>

<link href="res/profile.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css"/>

<div class="profile-container">
    <h1><?php echo ($viewUserId == $_SESSION['uid']) ? 'Your Profile' : $userData['username'] . "'s Profile"; ?></h1>

    <!-- Cover Photo Section -->
    <div class="cover-photo">
        <img id="currentCoverPhoto" class="cover-photo-img" src="<?php echo !empty($userData['cover_photo']) ? htmlspecialchars($userData['cover_photo']) : './media/default-cover.png'; ?>" alt="Cover Photo">
    </div>

    <!-- Profile Picture Section -->
    <div class="profile-header">
        <img class="profile-picture" src="<?php echo !empty($userData['profile_pic']) ? htmlspecialchars($userData['profile_pic']) : './media/default-profile.jpg'; ?>" alt="Profile Picture">
        <h1><?php echo htmlspecialchars($userData['firstname'] . ' ' . $userData['lastname']); ?></h1>
    </div>

    <!-- User Info Section -->
    <div class="profile-info">
        <p><strong>Username:</strong> <?php echo htmlspecialchars($userData['username']); ?></p>
        <p><strong>Full Name:</strong> <?php echo htmlspecialchars($userData['firstname'] . ' ' . $userData['lastname']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($userData['email']); ?></p>
        <p><strong>Gender:</strong> <?php echo htmlspecialchars($userData['gender']); ?></p>
        <p><strong>Birthdate:</strong> <?php echo htmlspecialchars($userData['birthdate']); ?></p>
        <p><strong>Bio:</strong> <?php echo htmlspecialchars($userData['bio']); ?></p>
    </div>

    <br>
    <?php if ($viewUserId == $_SESSION['uid']) { ?>
        <form id="editprofilename" action="./editprofilebio.php" method="POST">
            <button type="submit" class="edit-profile-btn">Edit Profile</button>
        </form>
    <br>

        <!-- Update Profile Picture -->
        <form id="profilePicForm" enctype="multipart/form-data" method="POST" class="update-form">
            <label for="profile_picture">Update Profile Picture:</label>
            <input type="file" name="profile_picture" id="profile_picture" class="file-input" required>
            <button type="submit" class="update-btn">Update Profile Picture</button>
        </form>
        <br>

        <!-- Update Cover Photo -->
        <form id="coverPhotoForm" enctype="multipart/form-data" method="POST" class="update-form">
            <label for="cover_photo">Update Cover Photo:</label>
            <input type="file" name="cover_photo" id="cover_photo" class="file-input" required>
            <button type="submit" class="update-btn">Update Cover Photo</button>
        </form>
    <?php } ?>

    <div id="statusMessage"></div>

    <?php if ($viewUserId == $_SESSION['uid']) { ?>
        <form id="add-post-form" action="models/add-post.php" method="POST" class="post-form">
            <textarea name="text_content" placeholder="What's on your mind?" required class="post-textarea"></textarea>
            <button type="submit" class="post-btn">Post</button>
            <div id="postMessage"></div>
        </form>
    <?php } ?>

    <!-- Post Container -->
    <div id="post-container">
        <?php
            // Fetch posts for the user
            $postQuery = "SELECT * FROM post WHERE uid = ? ORDER BY date DESC, time DESC";
            $postStmt = $conn->prepare($postQuery);
            $postStmt->bind_param("i", $viewUserId);
            $postStmt->execute();
            $postResult = $postStmt->get_result();

            if ($postResult->num_rows > 0) {
                while ($post = $postResult->fetch_assoc()) {
                    ?>
                    <div class="post">
                        <p><?php echo htmlspecialchars($post['text_content']); ?></p>
                        <p><small>Posted on: <?php echo htmlspecialchars($post['date']) . ' at ' . htmlspecialchars($post['time']); ?></small></p>

                        <?php if ($viewUserId == $_SESSION['uid']) { ?>
                            <a href="models/edit-post.php?pid=<?php echo $post['pid']; ?>" class="edit-post-btn">Edit</a> | 
                            <a href="models/delete-post.php?pid=<?php echo $post['pid']; ?>" class="delete-post-btn">Delete</a>
                        <?php } ?>

                        <div class="comments">
                            <?php
                            // Fetch comments for this post
                            $commentQuery = "SELECT comment.comment_text, user.username, comment.date FROM comment JOIN user ON comment.uid = user.uid WHERE comment.pid = ? ORDER BY comment.date DESC, comment.time DESC";
                            $commentStmt = $conn->prepare($commentQuery);
                            $commentStmt->bind_param("i", $post['pid']);
                            $commentStmt->execute();
                            $commentResult = $commentStmt->get_result();

                            while ($comment = $commentResult->fetch_assoc()) {
                                ?>
                                <div class="comment">
                                    <div class="comment-content">
                                        <div class="comment-header">
                                            <span class="comment-author"><?php echo htmlspecialchars($comment['username']); ?></span>
                                            <span class="comment-date"><?php echo htmlspecialchars($comment['date']); ?></span>
                                        </div>
                                        <div class="comment-text">
                                            <?php echo htmlspecialchars($comment['comment_text']); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>

                        <!-- Add a Comment Form -->
                        <form action="models/add-comment.php" method="POST" class="comment-form" id="comment-form-<?php echo $post['pid']; ?>">
                            <textarea name="comment_text" placeholder="Add a comment..." required class="comment-textarea"></textarea>
                            <input type="hidden" name="pid" value="<?php echo $post['pid']; ?>">
                            <button type="submit" class="comment-btn">Comment</button>
                        </form>
                    </div>
                    <?php
                }
            } else {
                echo "<p>No posts found.</p>";
            }
        ?>
    </div>
</div>

<!-- Include necessary JavaScript files -->
<script src="scripts/updateProfile.js"></script>
<script src="scripts/updateCover.js"></script>
<script src="scripts/add-post.js"></script>
<script src="scripts/load-profile-posts.js"></script>
<script src="scripts/submit-comment.js"></script>

<?php include 'views/footer.php'; ?>
