<?php

include 'views/header.php';

echo "SIGN OUT";

include 'views/footer.php';

?>
