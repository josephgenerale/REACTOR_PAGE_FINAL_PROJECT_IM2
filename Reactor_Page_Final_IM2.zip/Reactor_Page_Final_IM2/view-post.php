<?php 
session_start();
require_once('models/dbconnection.php');
$conn = create_connection();

if (!isset($_GET['pid']) || empty($_GET['pid'])) {
    echo "<h2>Post not found.</h2>";
    exit;
}

$pid = intval($_GET['pid']);

// Fetch post
$stmt = $conn->prepare("SELECT p.text_content, p.date, p.time, u.firstname, u.lastname, u.username, u.profile_pic, u.uid FROM post p JOIN user u ON p.uid = u.uid WHERE p.pid = ?");
$stmt->bind_param("i", $pid);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo "<h2>Post not found.</h2>";
    exit;
}
$post = $result->fetch_assoc();
$profilePic = $post['profile_pic'] ? $post['profile_pic'] : './media/default-profile.png';

// Fetch comments
$commentStmt = $conn->prepare("SELECT c.comment_text, c.date, c.time, u.firstname, u.lastname, u.username, u.uid FROM comment c JOIN user u ON c.uid = u.uid WHERE c.pid = ? ORDER BY c.date DESC, c.time DESC");
$commentStmt->bind_param("i", $pid);
$commentStmt->execute();
$commentResult = $commentStmt->get_result();
?>

<?php include('views/header.php'); ?>
<link rel="stylesheet" href="res/view-post.css" type="text/css"/>

<div class="post-container">
    <div class="post-author">
        <img src="<?php echo htmlspecialchars($profilePic); ?>" alt="Profile" class="post-author-pic">
        <div class="author-info">
            <h3>
                <a href="profile.php?uid=<?php echo urlencode($post['uid']); ?>" class="post-author-link">
                    <?php echo htmlspecialchars($post['firstname'] . ' ' . $post['lastname']); ?> (@<?php echo htmlspecialchars($post['username']); ?>)
                </a>
            </h3>
        </div>
    </div>

    <div class="post-content">
        <p><?php echo nl2br(htmlspecialchars($post['text_content'])); ?></p>
    </div>

    <div class="post-timestamp">
        <p class="timestamp"><?php echo htmlspecialchars($post['date'] . ' at ' . $post['time']); ?></p>
    </div>
</div>

<div class="comments-container">
    <h4>Comments</h4>

    <?php if ($commentResult->num_rows > 0): ?>
        <?php while ($comment = $commentResult->fetch_assoc()): ?>
            <?php
                $combinedDateTime = $comment['date'] . ' ' . $comment['time'];
                $formattedTime = date('F j, Y \a\t g:i A', strtotime($combinedDateTime));
            ?>
            <div class="comment">
                <div class="comment-header">
                    <a href="profile.php?uid=<?php echo urlencode($comment['uid']); ?>" class="comment-user">
                        <?php echo htmlspecialchars($comment['firstname'] . ' ' . $comment['lastname']); ?> (@<?php echo htmlspecialchars($comment['username']); ?>)
                    </a>:
                </div>
                <br>
                <p><?php echo nl2br(htmlspecialchars($comment['comment_text'])); ?></p>
                <p class="timestamp"><?php echo htmlspecialchars($formattedTime); ?></p>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No comments yet. Be the first to comment!</p>
    <?php endif; ?>
</div>

<?php if (isset($_SESSION['uid'])): ?>
    <div class="comment-form">
        <form action="models/add-comment.php" method="POST">
            <textarea name="comment_text" placeholder="Write a comment..." required></textarea>
            <input type="hidden" name="pid" value="<?php echo $pid; ?>">
            <button type="submit">Post Comment</button>
        </form>
    </div>
<?php else: ?>
    <p>You must be logged in to comment.</p>
<?php endif; ?>

<?php include('views/footer.php'); ?>
