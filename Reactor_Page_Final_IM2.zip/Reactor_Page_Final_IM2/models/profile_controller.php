<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // Ensure the session is started
}

// Check if user is logged in, if not, redirect to sign-in page
if (!isset($_SESSION['uid'])) {
    header("Location: ../sign-in.php"); // Redirect if not logged in
    exit;
}

// Include the database connection file
require 'dbconnection.php';

// Establish a connection to the database
$con = create_connection();

// Check for connection error
if ($con->connect_error) {
    die("Connection Failed: " . $con->connect_error);
}

// Make sure the session UID is numeric and valid
if (isset($_SESSION['uid']) && is_numeric($_SESSION['uid'])) {
    // Prepare the SQL query to fetch the user data based on session UID
    $sql = "SELECT username, firstname, lastname, email, gender, birthdate, bio, profile_pic, cover_photo FROM user WHERE uid = ?";
    $stmt = $con->prepare($sql);

    // Check if the prepared statement was successful
    if ($stmt) {
        // Bind the session UID parameter to the SQL query
        $stmt->bind_param("i", $_SESSION['uid']);
        // Execute the query
        $stmt->execute();
        // Get the result of the query
        $result = $stmt->get_result();

        // Check if a user was found
        if ($result->num_rows > 0) {
            // Fetch the user data as an associative array
            $userData = $result->fetch_assoc();
        } else {
            // No user data found, set $userData to null
            $userData = null;
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        // Error preparing the statement
        die('Prepare statement failed: ' . $con->error);
    }
} else {
    // Invalid session UID, exit with an error message
    die('Invalid session UID.');
}

// Close the database connection
$con->close();
?>
