<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('HTTP/1.1 405 Method Not Allowed');
    exit;
}

require '../models/dbconnection.php';
$conn = create_connection();

if (!$conn) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

$textContent = isset($_POST['text_content']) ? trim($_POST['text_content']) : '';
$userId = isset($_SESSION['uid']) ? $_SESSION['uid'] : null;

if (!$userId) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'User not logged in.']);
    exit;
}

if (empty($textContent)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Post content is empty.']);
    exit;
}

try {
    $stmt = $conn->prepare("INSERT INTO post (uid, text_content, date, time) VALUES (?, ?, CURDATE(), CURTIME())");
    $stmt->execute([$userId, $textContent]);

    header('location:../profile.php');
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database Error: ' . $e->getMessage()]);
}
exit;
?>
