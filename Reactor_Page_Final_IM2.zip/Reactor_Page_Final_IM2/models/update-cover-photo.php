<?php
session_start();
require 'dbconnection.php';

if (!isset($_SESSION['uid'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit;
}

$con = create_connection();

if ($con->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

$uid = $_SESSION['uid'];

if (!empty($_FILES['cover_photo']['name'])) {
    $targetDir = __DIR__ . "/../uploads/"; // ✅ Fixed path

    // ✅ Create a unique filename using timestamp
    $fileName = time() . '_' . basename($_FILES['cover_photo']['name']);
    $targetFilePath = $targetDir . $fileName;
    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

    // ✅ Allowed file types
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    if (in_array($fileType, $allowedTypes)) {
        // ✅ Ensure uploads directory is writable
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true); // ✅ Create directory if missing
        }

        if (!is_writable($targetDir)) {
            chmod($targetDir, 0777); // ✅ Set permissions
        }

        // ✅ Move file and update database
        if (move_uploaded_file($_FILES['cover_photo']['tmp_name'], $targetFilePath)) {
            $coverPhoto = "uploads/" . $fileName;

            $sql = "UPDATE user SET cover_photo = ? WHERE uid = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("si", $coverPhoto, $uid);

            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'newCoverPhoto' => $coverPhoto]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update cover photo in database.']);
            }

            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to upload file.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid file type.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'No file uploaded.']);
}

$con->close();
exit;
