<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['uid'])) {
    header("Location: ../sign-in.php");
    exit();
}

// Check if pid is set via GET request
if (isset($_GET['pid'])) {
    $pid = $_GET['pid'];

    require 'dbconnection.php';
    $conn = create_connection();

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch the post's text content that the user is allowed to edit
    $query = "SELECT text_content FROM post WHERE pid = ? AND uid = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $pid, $_SESSION['uid']);
    $stmt->execute();
    $stmt->bind_result($text_content);

    if ($stmt->fetch()) {
        // Display the form to edit the post
        ?>
        <link rel="stylesheet" href="../res/edit-post.css"> <!-- Link to the external CSS -->
        
        <!-- Form styled according to the provided CSS -->
        <div class="edit-post-container">
            <form action="update-post.php" method="POST">
                <input type="hidden" name="pid" value="<?php echo $pid; ?>"> <!-- Hidden field to pass pid -->
                <textarea name="text_content" rows="5" cols="50"><?php echo htmlspecialchars($text_content); ?></textarea><br>
                <button type="submit">Update Post</button>
            </form>
        </div>
        <?php
    } else {
        echo "Unauthorized or post not found.";
    }

    // Close prepared statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request.";
}
?>
