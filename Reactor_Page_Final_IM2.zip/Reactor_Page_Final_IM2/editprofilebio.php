<?php
session_start();
require 'models/dbconnection.php';
$conn = create_connection();

if (!isset($_SESSION['uid'])) {
    die("You are not logged in.");
}

$uid = $_SESSION['uid'];

$result = $conn->query("SELECT * FROM user WHERE uid = $uid");
if (!$result || $result->num_rows === 0) {
    die("User not found.");
}

$row = $result->fetch_assoc();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile & Bio</title>
    <link href="res/editprofilebio.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    <h1>Edit Profile</h1>
    <form method="post" action="models/editprofileandbio.php">
        <input type="text" name="username" value="<?= htmlspecialchars($row['username']) ?>" required>
        <input type="text" name="firstname" value="<?= htmlspecialchars($row['firstname']) ?>" required>
        <input type="text" name="lastname" value="<?= htmlspecialchars($row['lastname']) ?>" required>
        <input type="email" name="email" value="<?= htmlspecialchars($row['email']) ?>" required>
        <select name="gender" required>
            <option value="male" <?= $row['gender'] == 'male' ? 'selected' : '' ?>>Male</option>
            <option value="female" <?= $row['gender'] == 'female' ? 'selected' : '' ?>>Female</option>
        </select>
        <input type="date" name="birthdate" value="<?= htmlspecialchars($row['birthdate']) ?>" required>
        <input type="password" name="password" value="<?= htmlspecialchars($row['password']) ?>" required>
        <input type="text-content" name="bio" value="<?= htmlspecialchars($row['bio']) ?>">
        <button type="submit">Update</button>
    </form>
</body>
</html>
